miAppAngular.controller("menu", function($scope, $location) {

    $scope.isActive = function(route) {
        return route === $location.path();
    }
});