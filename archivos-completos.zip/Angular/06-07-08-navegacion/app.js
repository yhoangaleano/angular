var miAppAngular = angular.module('navegacion', ['ngRoute'] );

miAppAngular.config(function($routeProvider, $locationProvider){

    $locationProvider.hashPrefix("");

    $routeProvider.when('/' , {      
        templateUrl: 'partials/inicio.html',
        controller: 'inicio'
    })
    .when('/galeria', {
        templateUrl: 'partials/galeria.html',
        controller: 'inicio'
    })
    .when('/mapa', {
        templateUrl: 'partials/mapa.html',
        controller: 'inicio'
    })
    .when('/contacto', {
        templateUrl: 'partials/contacto.html',
        controller: 'inicio'
    })
    .when('/404', {
        templateUrl: 'partials/404.html',
        controller: 'inicio'
    })
    .otherwise({
        redirectTo: '/404'
    })
    
});