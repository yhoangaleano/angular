miAppAngular.service('carritoDeCompras', function() {
    
    this.productos;
    this.total;
    
})