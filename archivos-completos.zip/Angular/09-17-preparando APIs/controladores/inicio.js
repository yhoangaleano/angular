miAppAngular.controller('inicio', function($scope , $location , configuracionGlobal , $http){
	
	$scope.config = configuracionGlobal;
	
	$http.get( configuracionGlobal.api_url + "/readJornaleros")
	.then( function(respuesta){
		console.log(respuesta);
		$scope.jornaleros = respuesta.data.result;
	}, function(respuesta) {
		console.log(respuesta);
	});	
	
	$scope.verDetalles = function(_id){
		$location.path("/detalles/" + _id)
	}
	
});