miAppAngular.controller('detalles', function($scope , configuracionGlobal , $http,$location, $routeParams){

    $scope.config = configuracionGlobal;
    
    $http.get( configuracionGlobal.api_url + "/findJornalero",
    {
        params: { idJornalero: $routeParams.idJornalero }
    })
    .then( function(respuesta){
        $scope.jornalero = respuesta.data.result[0];
    });
    
    
    
    $scope.guardarInfo = function(){

        $http({
            url: configuracionGlobal.api_url + "/updateSimple",
            method: "POST",
            data: $scope.jornalero
        })
        .then(function(response) {// success
            alert("Actualizado con exito");
            $location.path("/");
        });
    }
    
    
    
    
});