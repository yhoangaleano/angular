miAppAngular.controller("menu", function($scope, $location, configuracionGlobal) {

	$scope.config =  configuracionGlobal;
	
	$scope.isActive = function(route) {
		return route === $location.path();
	}
});