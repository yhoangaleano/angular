var miAppAngular = angular.module('navegacion', ['ngRoute'] );

miAppAngular.config( function($routeProvider, $locationProvider){

    $locationProvider.hashPrefix("");

    $routeProvider.when('/' , {      
        templateUrl: 'partials/inicio.html',
        controller: 'inicio'
    })
    .when('/detalles/:idJornalero', {
        templateUrl: 'partials/detalles.html',
        controller: 'detalles'
    })
    .when('/404', {
        templateUrl: 'partials/404.html',
        controller: 'inicio'
    })
    .otherwise({

        redirectTo: '/404'
        
    })
    
});


miAppAngular.constant('configuracionGlobal', {
    'nombreDelSitio':'Finca El Berriondo',
    'api_url': 'http://localhost/Especializacion/api',
    'carpeta_imagenes': 'imagenes/',
})